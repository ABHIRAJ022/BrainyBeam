import os

def analyze_txt_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()

    paragraphs = text.split('\n\n')
    words = text.split()
    sentences = [s for s in text.replace('\n', ' ').split('.') if s.strip()]
    file_size = os.path.getsize(filepath)

    return {
        'Paragraphs': len(paragraphs),
        'Words': len(words),
        'Sentences': len(sentences),
        'File Size (Bytes)': file_size
    }

if __name__ == "__main__":
    path = input("Enter full path of .txt file: ").strip('"')
    if os.path.exists(path) and path.endswith('.txt'):
        stats = analyze_txt_file(path)
        print("\nFile Analysis:")
        for key, value in stats.items():
            print(f"{key}: {value}")
    else:
        print("Invalid file path or not a .txt file.")
        

#python Count.py