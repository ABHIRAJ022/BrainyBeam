from docx import Document
from reportlab.pdfgen import canvas

def docx_to_pdf_alternative(docx_path, pdf_path):
    try:
        doc = Document(docx_path)
        c = canvas.Canvas(pdf_path)
        y = 800

        for para in doc.paragraphs:
            c.drawString(50, y, para.text)
            y -= 20
            if y < 50:
                c.showPage()
                y = 800

        c.save()
        print("✅ PDF created successfully.")
    except Exception as e:
        print("❌ Error:", e)

if __name__ == "__main__":
    docx_path = input("Enter full path of .docx file: ").strip('"')
    pdf_path = input("Enter full path to save .pdf file: ").strip('"')
    docx_to_pdf_alternative(docx_path, pdf_path)

import os
print(os.getcwd())

'''
pip install python-docx reportlab
python DocxToPdf.py

'''