import tkinter as tk
from tkinter import filedialog
from PIL import ImageTk, Image

class ImageViewer:
    def __init__(self, root):
        self.root = root
        self.root.title("Multiple Image Viewer")
        self.image_labels = []
        self.load_images()

    def load_images(self):
        file_paths = filedialog.askopenfilenames(filetypes=[("Image Files", "*.png *.jpg *.jpeg *.gif")])
        for path in file_paths:
            img = Image.open(path)
            img = img.resize((200, 200))
            photo = ImageTk.PhotoImage(img)
            label = tk.Label(self.root, image=photo)
            label.image = photo
            label.pack(side="left", padx=10)
            self.image_labels.append(label)

if __name__ == "__main__":
    root = tk.Tk()
    viewer = ImageViewer(root)
    root.mainloop()

'''
pip install pillow
python ImgViewer.py

'''