from django.urls import path
from .views import paginated_view

urlpatterns = [
    path('', paginated_view, name='home'),
]
