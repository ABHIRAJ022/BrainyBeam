from django.core.paginator import Paginator
from django.shortcuts import render
from .models import Item

def paginated_view(request):
    search_query = request.GET.get('q', '')
    if search_query:
        items = Item.objects.filter(title__icontains=search_query)
    else:
        items = Item.objects.all()

    paginator = Paginator(items, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'core/paginated_template.html', {'page_obj': page_obj, 'query': search_query})
