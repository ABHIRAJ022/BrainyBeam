from gtts import gTTS
import os

def text_to_speech(text, username):
    folder = os.path.join(os.getcwd(), username)
    os.makedirs(folder, exist_ok=True)
    output_path = os.path.join(folder, f"{username}_audio.mp3")
    
    try:
        tts = gTTS(text=text, lang='en')
        tts.save(output_path)
        print(f"Audio saved to: {output_path}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    user_input = input("Enter text to convert to speech: ")
    name = input("Enter your username: ")
    text_to_speech(user_input, name)

'''

pip install gTTS
python TextToSpeech.py

'''